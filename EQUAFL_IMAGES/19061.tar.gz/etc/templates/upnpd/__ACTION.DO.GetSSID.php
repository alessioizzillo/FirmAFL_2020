<NewSSID><?
	query("/wireless/ssid");
?></NewSSID>