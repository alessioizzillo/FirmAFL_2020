<html>
<head>
<title></title>
</head>
<script>
function init()
{
	parent.location.href="web_redirect.php";
}
</script>
<body onload="init();">
	
</body>
</html>
