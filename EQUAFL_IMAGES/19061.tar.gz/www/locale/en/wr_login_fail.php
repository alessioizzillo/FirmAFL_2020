<?
$m_html_title	= "LOGIN FAIL";
$m_context_title= "Web Redirect Authentication fail";
$m_context	= "Username or Password is invalid.";
$m_button_dsc	= "Retry";
$m_close ="Close";
?>
