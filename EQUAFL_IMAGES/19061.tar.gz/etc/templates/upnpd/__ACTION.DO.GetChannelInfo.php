<NewChannel><?
	query("/wireless/channel");
?></NewChannel>
<NewPossibleChannels>0-200</NewPossibleChannels>