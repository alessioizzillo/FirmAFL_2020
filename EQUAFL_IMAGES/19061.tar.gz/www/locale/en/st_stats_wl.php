<?
$m_band_2.4G = "2.4GHz";
$m_band_5G = "5GHz";

$msg_title="WLAN Traffic Statistics";
$msg_t_title="Transmitted Count";
$msg_t_msg1="Transmitted Packet Count";
$msg_t_msg2="Transmitted Bytes Count";
$msg_t_msg3="Dropped Packet Count";
$msg_t_msg4="Transmitted Retry Count";
$msg_r_title="Received Count";
$msg_r_msg1="Received Packet Count";
$msg_r_msg2="Received Bytes Count";
$msg_r_msg3="Dropped Packet Count";
$msg_r_msg4="Received CRC Count";
$msg_r_msg5="Received Decryption Error Count";
$msg_r_msg6="Received MIC Error Count";
$msg_r_msg7="Received PHY Error Count";
$msg_clear="Clear";
$msg_refresh="Refresh";




?>