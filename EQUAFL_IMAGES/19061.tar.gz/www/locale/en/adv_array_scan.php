<?
$m_disable = "Disable";
$m_enable = "Enable AP Array";
$m_version = "Version";
$m_scan = "Scan";
$m_context_title= "AP Array Scan";
$m_master = "Master";
$m_backup_master = "Backup Master";
$m_slave = "Slave";
$m_ap_array_name = "AP Array Name";
$m_ap_array_pwd = "AP Array Password";
$m_scan_ap_array = "Scan AP Array List";
$m_connection_status = "Connection Status";
$m_ap_array_list = "AP Array List";
$m_discover = "Discover";
$m_array_name = "Array Name";
$m_master_ip = "Master IP";
$m_mac = "MAC";
$m_total = "Total"; 
$m_current_ap_array_tlb = "Current Members";
$m_index = "Index";
$m_rule = "Role";
$m_ip_addr = "IP Address";
$m_mac_addr = "MAC Address";
$m_location = "Location";
$m_sync_parameter = "Synchronized Parameters";
$m_connect = "Connect";
$m_disconnect = "Disconnect";

$a_empty_name	= "The AP Array Name field can not be blank.";
$a_invalid_name	= "There are some invalid characters in the AP Array Name field. Please check it.";
$a_first_blank_name	= "The first character can't be blank.";
$a_first_end_blank  = "The first character and last character can't be blank.";
$a_invalid_password	="The Password is with invalid character. Please check it.";
$a_LimitAdministrator_change="If AP Array Status is enabled, Limit Administrator Status will be disabled.";
$a_disable_sw_ctrl = "Central WiFiManager will be disabled if AP Array is enabled.";
?>
