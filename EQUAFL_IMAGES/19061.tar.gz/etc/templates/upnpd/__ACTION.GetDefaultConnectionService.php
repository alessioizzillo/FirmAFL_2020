<NewDefaultConnectionService><?

	query("/runtime/upnpdev/root:1/udn");
	echo ":WANConnectionDevice:1,";
	query("/runtime/upnpdev/root:1/device:1/device:1/service:2/serviceid");

?></NewDefaultConnectionService>
