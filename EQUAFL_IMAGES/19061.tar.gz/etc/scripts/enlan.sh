#!/bin/sh
echo [$0] ... > /dev/console
