<?
$a_invalid_user_name	="Please input the Username.";
$m_username	="Username";
$m_html_title		="LOGIN";
$m_context_title	="Web Redirect Authentication";
$m_login_ap		="Authentication:";
$m_log_in		=" Submit ";
?>
