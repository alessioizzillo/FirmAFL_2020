<?
$m_html_title="UPLOAD";
$m_context_title="Upload";
$m_context="Picture size is too large, must be less than 384Kb!!!<br>Please try again.";
$m_button_dsc="Back";
?>
