<?
set("/runtime/web/display/sys/hostname","DAP-3520");
set("/runtime/web/display/utilization","0");
set("/runtime/web/display/nap_server","0");
?>