<?
$UPNPMSG=query("/runtime/upnpmsg");
if ($UPNPMSG=="") {$UPNPMSG="/dev/null";}
?>
