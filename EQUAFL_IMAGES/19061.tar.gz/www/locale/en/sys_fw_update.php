<?
$m_menu_upgrade_fw = "<font face=\"Arial\" color=\"red\" size=2>".
					 "<b>Do Not Power Down </b></font>".
					 "<font face=\"Arial\" size=2>Your Device During This Process.".
					 "Doing So May Physically Damage Your ".query("/sys/hostname").
					 ". (If your browser does not redirect to the web page automatically,".
					 "please press the refresh button.)</font>";
					 
$m_upload_fw = "Uploading Firmware ...";
$m_verify_fw = "Verifying Firmware ...";
$m_upgrad_device = "Upgrading Device ...";
$m_reboot_device = "Rebooting Device ...";

$a_upgrade_fw_fail_msg = "Firmware upgrade is failed, please reload the firmware and try again.";

?>