<?
$m_html_title="UPLOAD";
$m_context_title="Upload Error";
$m_context="List is more than 64 rules per ssid!!!";
$m_button_dsc="Back";
?>
