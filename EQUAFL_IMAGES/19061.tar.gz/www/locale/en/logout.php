<?
$m_html_title="LOGOUT";
$m_context_title="Logout";
$m_context="You have successfully logout.";
$m_button_dsc="Return to login page";
?>
