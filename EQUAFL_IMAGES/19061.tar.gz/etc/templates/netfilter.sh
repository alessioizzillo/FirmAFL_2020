	rgdb -A /etc/templates/netfilter.php
	sh /var/run/__netfilter.sh

