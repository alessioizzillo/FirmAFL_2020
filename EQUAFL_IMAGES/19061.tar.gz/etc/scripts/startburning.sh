#!/bin/sh
umount /www/locale/alt 

