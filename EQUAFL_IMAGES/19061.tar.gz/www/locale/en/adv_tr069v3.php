<?

$a_acs_url="Invalid ACS url!";
$a_acs_default_url="Invalid ACS default url!";
$a_cpe_url="Invalid CPE url!";
$a_periodic_inform_interval="The Value of the Periodic Inform Interval should be a number!";

$m_acs_username_bank="ACS user name can not bank";
$m_acs_passwd_bank="";
$m_cpe_username_bank="";
$m_cpe_passwd_bank="";

$m_tr069_title="TR069 Configuration";
$tr069_enable="Enabled TR069";
$tr069_ssl_enable="SSL status";
$acs_url="ACS URL";
$acs_user_name="Username";
$acs_passwd="Password";
$tr069_periodic_enalbe="Periodic Inform Enable";
$tr069_periodic_interval="Periodic Inform Interval";
$cpe_url="Connection Request URL";
$cpe_user_name="Connection Request Username";
$cpe_passwd="Connection Request Password";
$upgrade_managed="Upgrade Managed";
$product_class="Managed Product Class";
$manufacturer_oui="Manufacturer OUI";
$serial_number="Serial Number";



$m_tr069_descript="A protocol for communication between a CPE and Auto-Configuration Server (ACS).";
$m_acs_default_url="Default ACS URL";
$m_acs_url="ACS URL";
$m_cpe_url="CPE URL";
$m_acs_username="Username";
$m_acs_password="Password";
$m_periodic_inform_enable="Periodic Inform Enable";
$m_periodic_inform_interval="Periodic Inform Interval";
$m_periodic_inform_time="Periodic Inform Time";
$m_time="Time";
$m_year="Year";
$m_month="Month";
$m_day="Day";
$m_hour="Hour";
$m_minute="Minute";
$m_second="Second";
?>
