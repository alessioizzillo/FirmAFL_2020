	rgdb -A /etc/templates/limitedadmin.php
	sh /var/run/__limitedadmin.sh
        
	/etc/scripts/eth_vlan.sh start    > /dev/console
