<?
$declare = "this area is 700*300 ,you can upload jpg here";
$username = "UserName";
$password = "Password";
$submit = "Submit";
$fail = "Captival Portal Login Fail";
$passcode = "Passcode";
$success = "Captival Portal Login Success";
?>