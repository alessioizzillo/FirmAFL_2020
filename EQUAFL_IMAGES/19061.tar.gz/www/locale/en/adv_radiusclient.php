<? 
$m_context_title="Radiusclient";
$m_radiusclient = "Radiusclient Enable";
$m_radius_server_ip ="RADIUS Server IP";
$m_radius_server_pwd ="RADIUS Server Password";
$m_radius_secret = "RADIUS Secret";
$m_radius_server ="RADIUS Server";
$m_disable = "Disable";
$m_enable = "Enable";

$a_invalid_radius_srv	= "The IP Address of RADIUS Server is invalid.";
$a_empty_radius_sec	= "The Shared Secret of RADIUS Server can not be empty.";
$a_invalid_radius_sec	= "The Shared Secret of RADIUS Server should be ASCII characters.";

?>