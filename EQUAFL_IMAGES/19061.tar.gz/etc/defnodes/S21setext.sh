#!/bin/sh
#xmldbc -x /runtime/genuuid "get:genuuid -r"
#xmldbc -x /runtime/genpin  "get:wps -g"
