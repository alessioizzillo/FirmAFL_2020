<?
set("/runtime/web/display/sys/hostname","DAP-1353");
set("/runtime/web/display/rts","0");
set("/runtime/web/display/frag","0");
set("/runtime/web/display/utilization","0");
set("/runtime/web/display/nap_server","1");
set("/runtime/web/display/backup_radius_server","0");
set("/runtime/web/display/accounting_server","0");
set("/runtime/web/display/backup_accounting_server","0");
set("/runtime/web/display/status/ap_status","0");
set("/runtime/web/display/status/cpu","0");
set("/runtime/web/display/status/memory","0");
set("/runtime/web/display/statistics/received","0");
set("/runtime/web/display/statistics/len","0");
set("/runtime/web/display/log/email","1");
set("/runtime/web/display/autorekey","1");
set("/runtime/web/display/snmp/trap","1");
set("/runtime/web/display/ping_control","0");
set("/runtime/web/display/stat_wl","1");
set("/runtime/web/display/priority","1");
set("/runtime/web/display/mssid_index4","1");
set("/runtime/web/display/language","1");
set("/runtime/web/display/schedule_wireless","0");
set("/runtime/web/display/ap_array","1");
set("/runtime/web/display/url_redir","0");
set("/runtime/web/display/wisp","0");
set("/runtime/web/display/radiusclient","0");
set("/runtime/web/display/ap_repeater","1");
set("/runtime/web/display/aclupdnload","1");
set("/runtime/web/display/macclone","1");
set("/runtime/web/display/mcast","1");
set("/runtime/web/display/mssid_index0","0");

//set("/runtime/web/display/wlmode_support_n_only","1");
set("/runtime/web/display/mssid_support_sharedkey","0");
set("/runtime/web/display/multi_dhcp","1");
set("/runtime/web/display/ack_timeout_range","1");

set("/runtime/web/display/802.1x_support", "1");
set("/runtime/web/display/local_radius_server", "0");
?>
