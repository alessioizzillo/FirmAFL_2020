<NewRSIPAvailable>0</NewRSIPAvailable>
<NewNATEnabled><?=$ROUTER_ON?></NewNATEnabled>
