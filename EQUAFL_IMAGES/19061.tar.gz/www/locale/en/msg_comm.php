<?
$m_user_name		="User Name";
$m_password		="Password";
$m_continue		="Continue";
$m_nochg_title		="No Changes";
$m_nochg_dsc		="Settings have not changed.";
$m_saving_title		="Saving";
$m_saving_dsc		="The settings are saving and taking effect.";
$m_saving_dsc_wait = "Please wait ...";
$m_saving_dsc_change_ip = "Please wait 10 seconds then access the device with new IP Address.";
$m_scan_title		="Scan";
$m_detect_title	="Detect";
$m_scan_dsc		="Scanning ... <br><br> Please wait ...";
$m_clear = "Clear";

$TITLE=query("/sys/web/sysname");
$first_frame = "home_sys";
//$m_logo_title	=query("/sys/web/sysname");
$m_logo_title =query("/sys/hostname");
?>
